# Smart Medicine Reminder Box — Setup Guide

## Project structure
```
smart_medicine_app/
├── app.py              (backend - Python Flask)
├── requirements.txt
├── medicine.db         (auto-created on first run - SQLite database)
├── templates/
│   └── index.html      (frontend page)
└── static/
    ├── style.css        (frontend styling)
    └── script.js        (frontend logic - talks to backend)
```

## STEP 1 — First time setup (do this on your laptop, WITH internet)

1. Check Python is installed:
   ```
   python --version
   ```
   (If not installed, download from python.org and install first)

2. Open terminal/command prompt inside the `smart_medicine_app` folder and run:
   ```
   pip install -r requirements.txt
   ```
   This installs Flask. Do this once, while you have internet.

## STEP 2 — Running the project (works WITHOUT internet after Step 1)

1. Open terminal inside the `smart_medicine_app` folder
2. Run:
   ```
   python app.py
   ```
3. You'll see something like: `Running on http://127.0.0.1:5000`
4. Open your browser and go to: **http://127.0.0.1:5000**
5. Done — the app is running fully offline (no internet needed at this point,
   everything is on localhost / your own machine)

## STEP 3 — Taking it to college lab

- Copy the ENTIRE `smart_medicine_app` folder (pendrive/email/drive) to the lab computer
- Check if Python is already installed on the lab PC (`python --version`)
- If Flask is not installed on the lab PC and there's no internet there:
  - Best option: install Flask on your laptop, then copy the whole Python
    installation folder is not practical — instead, ask your lab in-charge
    if Flask can be pre-installed, OR carry your own laptop for the demo
    (most colleges allow this for project reviews)
  - Alternative: run it on your laptop and just connect it to the projector/
    show the screen — no need to run on the lab PC itself
- Once `python app.py` runs, everything (backend + database + frontend) is
  100% local — no internet is contacted at any point

## How to demo it (viva tips)

1. Add 2-3 medicines with different time slots (Morning/Afternoon/etc.)
2. Set one reminder time to 1-2 minutes from now — wait and show the LED
   blinking + beep sound triggering automatically (shows real-time backend
   logic working)
3. Use "Simulate now" button on another reminder to instantly trigger it
   (saves time during a live review)
4. Click "Mark taken" to show status updates being saved
5. Refresh the browser page — show that reminders are still there
   (proves data is saved in the SQLite database, not just in browser memory)
6. Open the `medicine.db` file with "DB Browser for SQLite" (free tool) if
   asked to show the database table directly

## Tech stack summary (for your report)

- **Frontend:** HTML, CSS, JavaScript (fetch API for calling backend)
- **Backend:** Python, Flask (REST API — GET/POST/DELETE routes)
- **Database:** SQLite (file-based, no server install needed)
- **Architecture:** Client-server, frontend polls backend every second to
  check reminder times against the system clock
