from flask import Flask, render_template, request, jsonify
import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'medicine.db')

app = Flask(__name__)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute('''CREATE TABLE IF NOT EXISTS reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slot TEXT NOT NULL,
        time TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'upcoming'
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message TEXT NOT NULL,
        logged_at TEXT NOT NULL
    )''')
    conn.commit()
    conn.close()


def log_activity(conn, message):
    conn.execute(
        'INSERT INTO activity_log (message, logged_at) VALUES (?, ?)',
        (message, datetime.now().strftime('%H:%M:%S'))
    )
    conn.commit()


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/reminders', methods=['GET'])
def get_reminders():
    conn = get_db()
    rows = conn.execute('SELECT * FROM reminders ORDER BY time').fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.route('/api/reminders', methods=['POST'])
def add_reminder():
    data = request.get_json(force=True)
    name = (data.get('name') or '').strip()
    slot = data.get('slot')
    time_ = data.get('time')

    if not name or not time_ or slot not in ('Morning', 'Afternoon', 'Evening', 'Night'):
        return jsonify({'error': 'Missing or invalid fields'}), 400

    conn = get_db()
    conn.execute(
        'INSERT INTO reminders (name, slot, time, status) VALUES (?, ?, ?, ?)',
        (name, slot, time_, 'upcoming')
    )
    conn.commit()
    log_activity(conn, f'Added: {name} ({slot}, {time_})')
    conn.close()
    return jsonify({'ok': True})


@app.route('/api/reminders/<int:rid>/status', methods=['POST'])
def update_status(rid):
    data = request.get_json(force=True)
    status = data.get('status')
    if status not in ('upcoming', 'due', 'taken', 'missed'):
        return jsonify({'error': 'Invalid status'}), 400

    conn = get_db()
    r = conn.execute('SELECT * FROM reminders WHERE id = ?', (rid,)).fetchone()
    if not r:
        conn.close()
        return jsonify({'error': 'Not found'}), 404

    conn.execute('UPDATE reminders SET status = ? WHERE id = ?', (status, rid))
    conn.commit()

    label = {'taken': 'Marked taken', 'due': 'Simulated trigger', 'missed': 'Missed'}.get(status, status)
    log_activity(conn, f'{label}: {r["name"]}')
    conn.close()
    return jsonify({'ok': True})


@app.route('/api/reminders/<int:rid>', methods=['DELETE'])
def delete_reminder(rid):
    conn = get_db()
    r = conn.execute('SELECT * FROM reminders WHERE id = ?', (rid,)).fetchone()
    conn.execute('DELETE FROM reminders WHERE id = ?', (rid,))
    conn.commit()
    if r:
        log_activity(conn, f'Removed: {r["name"]}')
    conn.close()
    return jsonify({'ok': True})


@app.route('/api/check', methods=['POST'])
def check_schedule():
    """Polled every second by the frontend. Compares server clock to each
    reminder's time and flips matching rows from 'upcoming' to 'due'."""
    now = datetime.now().strftime('%H:%M')
    conn = get_db()
    due_rows = conn.execute(
        "SELECT * FROM reminders WHERE status = 'upcoming' AND time = ?", (now,)
    ).fetchall()

    triggered = []
    for r in due_rows:
        conn.execute("UPDATE reminders SET status = 'due' WHERE id = ?", (r['id'],))
        log_activity(conn, f'Reminder triggered: {r["name"]} ({r["slot"]})')
        triggered.append(dict(r))

    conn.close()
    return jsonify({'now': now, 'triggered': triggered})


@app.route('/api/log', methods=['GET'])
def get_log():
    conn = get_db()
    rows = conn.execute('SELECT * FROM activity_log ORDER BY id DESC LIMIT 30').fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
