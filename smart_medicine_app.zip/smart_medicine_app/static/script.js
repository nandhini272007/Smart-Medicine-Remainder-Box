const SLOTS = ["Morning", "Afternoon", "Evening", "Night"];
let audioCtx = null;

function beep() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = 'square';
    o.frequency.value = 880;
    g.gain.value = 0.06;
    o.connect(g); g.connect(audioCtx.destination);
    o.start();
    setTimeout(() => { o.frequency.value = 660; }, 150);
    setTimeout(() => { o.stop(); }, 320);
  } catch (e) { /* audio unavailable, ignore */ }
}

function pad(n) { return n.toString().padStart(2, '0'); }

function updateClock() {
  const d = new Date();
  document.getElementById('clockTime').textContent =
    pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function showToast(title, body) {
  const t = document.getElementById('toast');
  document.getElementById('toastTitle').textContent = title;
  document.getElementById('toastBody').textContent = body;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}

async function fetchReminders() {
  const res = await fetch('/api/reminders');
  return res.json();
}

async function fetchLog() {
  const res = await fetch('/api/log');
  return res.json();
}

function renderCompartments(reminders) {
  const wrap = document.getElementById('compartments');
  wrap.innerHTML = '';
  SLOTS.forEach(slot => {
    const slotReminders = reminders.filter(r => r.slot === slot);
    const anyDue = slotReminders.some(r => r.status === 'due');
    const anyMissed = slotReminders.some(r => r.status === 'missed');
    const allTaken = slotReminders.length > 0 && slotReminders.every(r => r.status === 'taken');

    const div = document.createElement('div');
    div.className = 'slot' + (anyDue ? ' due' : '') + (allTaken ? ' taken' : '') + (!anyDue && anyMissed ? ' missed' : '');
    div.innerHTML = `
      <div class="led"></div>
      <div class="slot-name">${slot}</div>
      <div class="slot-time">${slotReminders.length ? slotReminders.map(r => r.time).join(', ') : '— empty —'}</div>
      <div class="slot-count">${slotReminders.length} med${slotReminders.length === 1 ? '' : 's'}</div>
    `;
    wrap.appendChild(div);
  });
}

function renderList(reminders) {
  const box = document.getElementById('reminderList');
  if (reminders.length === 0) {
    box.innerHTML = '<div class="empty">No reminders yet. Add one on the left.</div>';
    return;
  }
  const statusLabel = { upcoming: '⏳ Upcoming', due: '🔔 Due now', taken: '✅ Taken', missed: '⚠ Missed' };
  box.innerHTML = '';
  reminders.slice().sort((a, b) => a.time.localeCompare(b.time)).forEach(r => {
    const row = document.createElement('div');
    row.className = 'list-item';
    row.innerHTML = `
      <span><span class="li-name">${r.name}</span><br><span class="li-meta">${r.slot} · ${r.time} · ${statusLabel[r.status]}</span></span>
      <span class="li-actions">
        ${r.status === 'due' ? `<button class="btn sim" data-action="take" data-id="${r.id}">Mark taken</button>` : ''}
        <button class="btn sim" data-action="simulate" data-id="${r.id}">Simulate now</button>
        <button class="btn ghost" data-action="delete" data-id="${r.id}">Remove</button>
      </span>
    `;
    box.appendChild(row);
  });
}

function renderLog(entries) {
  const box = document.getElementById('activityLog');
  if (entries.length === 0) {
    box.innerHTML = '<div class="empty">No activity yet.</div>';
    return;
  }
  box.innerHTML = '';
  entries.forEach(e => {
    const row = document.createElement('div');
    row.className = 'list-item';
    row.innerHTML = `<span>${e.message}</span><span class="li-meta">${e.logged_at}</span>`;
    box.appendChild(row);
  });
}

async function refreshAll() {
  const reminders = await fetchReminders();
  renderCompartments(reminders);
  renderList(reminders);
  const entries = await fetchLog();
  renderLog(entries);
}

async function addReminder() {
  const nameEl = document.getElementById('medName');
  const slotEl = document.getElementById('medSlot');
  const timeEl = document.getElementById('medTime');
  const msg = document.getElementById('formMsg');

  const name = nameEl.value.trim();
  const slot = slotEl.value;
  const time = timeEl.value;

  if (!name || !time) {
    msg.textContent = 'Enter both medicine name and time.';
    return;
  }
  msg.textContent = '';

  const res = await fetch('/api/reminders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, slot, time })
  });
  if (res.ok) {
    nameEl.value = '';
    timeEl.value = '';
    await refreshAll();
  } else {
    const data = await res.json();
    msg.textContent = data.error || 'Could not add reminder.';
  }
}

async function checkSchedule() {
  const res = await fetch('/api/check', { method: 'POST' });
  const data = await res.json();
  if (data.triggered && data.triggered.length > 0) {
    data.triggered.forEach(r => {
      beep();
      showToast('Time for medicine', `${r.name} — ${r.slot}`);
    });
    await refreshAll();
  }
}

document.getElementById('addBtn').addEventListener('click', addReminder);

document.getElementById('reminderList').addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const id = btn.dataset.id;
  const action = btn.dataset.action;

  if (action === 'take') {
    await fetch(`/api/reminders/${id}/status`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'taken' })
    });
  } else if (action === 'simulate') {
    await fetch(`/api/reminders/${id}/status`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'due' })
    });
    beep();
    showToast('Time for medicine', 'Reminder simulated');
  } else if (action === 'delete') {
    await fetch(`/api/reminders/${id}`, { method: 'DELETE' });
  }
  await refreshAll();
});

setInterval(() => { updateClock(); checkSchedule(); }, 1000);
updateClock();
refreshAll();
